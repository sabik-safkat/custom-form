<div class="col item">
	<div class="card">
		<img class="card-img-top img-fluid" src="img/project.jpg" alt="Card image cap">
		<div class="card-block">
			<p class="card-text"><a href="">カンボジアの子供たちに服を届けたい!</a></p>
			<button class="btn btn-sm btn-success"><i class="fa fa-pencil"></i> 支援する</button>
			<div class="row text-center mt20">
				
				<div class="col box">
					<h5>14</h5>
					<small><i class="fa fa-user"></i> some text</small>
				</div>
				
				
				<div class="col box">
					<small>some text</small>
					<h5>some</h5>
				</div>
				
			</div>
			<div class="row mt20">
				<div class="col text-right text-success">
					<h5><i class="fa fa-jpy"> 90,0000</i></h5>
				</div>
			</div>
			<div class="progress">
				<div class="progress-bar bg-success w-75" role="progressbar" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100">
					75%
				</div>
			</div>
		</div>
	</div>
</div>