<?php include('include/header.php'); ?>

<div class="row mt20 text-right">
	<div class="col">
		<div><i class="fa fa-search"> some text</i></div>
		<form class="form-inline pull-right">
          <div class="input-group">
			  <input type="text" class="form-control" placeholder="search" aria-describedby="basic-addon2">
			  <span class="input-group-addon" id="basic-addon2"><i class="fa fa-search"></i></span>
			</div>
        </form>
	</div>	
</div>
<div class="mt20">
	<div class="row">
		<div class="col-md-10">
			
		</div>

		<div class="col-md-2 mt50">
			<img src="http://via.placeholder.com/200x800" class="img-fluid">
		</div>
	</div>
	
</div>


<?php include('include/footer.php'); ?>


		